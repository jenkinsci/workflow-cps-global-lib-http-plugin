I am a file in an extra directory used for testing purposes.
